import { Link } from 'react-router-dom';

function Dashboard() {
  const containerStyle = {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    height: '100vh',
    flexDirection: 'column',
  };

  const buttonStyle = {
    marginTop: '20px',
    padding: '10px 20px',
    textDecoration: 'none',
    color: 'white',
    backgroundColor: 'blue',
    border: 'none',
    borderRadius: '5px',
  };

  return (
    <div style={containerStyle}>
      <h2>Bienvenido al Dashboard</h2>
      <p>Has iniciado sesión correctamente.</p>
      <Link to="/" style={buttonStyle}>Cerrar sesión</Link>
    </div>
  );
}

export default Dashboard;