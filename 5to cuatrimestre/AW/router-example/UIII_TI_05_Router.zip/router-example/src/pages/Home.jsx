import React from 'react'

export default function Home() {
    return (
        <div>
            <h1>Está es la página Home</h1>
            
        </div>
    )
}
