import React from 'react'

export default function ErrorPage() {
    return (
        <div>
            <h1>PAGE NOT FOUND</h1>
            
        </div>
    )
}
