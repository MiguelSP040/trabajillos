import React from 'react'

export default function About() {
    return (
        <div>
            <h1>Esta es la pagina de About</h1>
        </div>
    )
}
